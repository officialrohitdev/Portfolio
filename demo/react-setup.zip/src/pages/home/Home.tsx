import './home.css'

function Home() {
  return (
    <section id="center">
      <h1>Home</h1>
      <p>Welcome to the home page.</p>
    </section>
  )
}

export default Home
