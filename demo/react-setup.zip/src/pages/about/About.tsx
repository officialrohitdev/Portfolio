import './about.css'

function About() {
  return (
    <section id="center">
      <h1>About</h1>
      <p>About this app.</p>
    </section>
  )
}

export default About
